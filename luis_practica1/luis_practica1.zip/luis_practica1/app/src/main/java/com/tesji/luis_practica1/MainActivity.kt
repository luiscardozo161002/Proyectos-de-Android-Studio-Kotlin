package com.tesji.luis_practica1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.tesji.luis_practica1.model.PrestacionesModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Declarar los Views y referenciarlos por su ID
        val txtNombreEmpleado = findViewById<EditText>(R.id.txNombreEmpleado)
        val txtSalarioMensual = findViewById<EditText>(R.id.txSalarioMensual)
        val txtDiasInicioLaborados = findViewById<EditText>(R.id.txDiasInicioLaborados)
        val txtDiasFinLaborados = findViewById<EditText>(R.id.txDiasFinLaborados)
        val txtDiasInasistencia = findViewById<EditText>(R.id.txDiasInasistencia)
        val btnCalcularPagoSalario = findViewById<Button>(R.id.btCalcularPago)

        // Obtener una referencia al EditText donde mostrar el resultado
        val txResultado = findViewById<EditText>(R.id.txResultado)

        // Crear el evento clic del botón
        btnCalcularPagoSalario.setOnClickListener {
            // Eliminar espacios y verificar las entradas de texto
            if (txtNombreEmpleado.text.toString().trim().isEmpty()) {
                txtNombreEmpleado.setError("Ingresa Nombre del Empleado")
            } else if (txtSalarioMensual.text.toString().trim().isEmpty()) {
                txtSalarioMensual.setError("Ingrese Salario Mensual")
            } else if (txtDiasInicioLaborados.text.toString().trim().isEmpty()) {
                txtDiasInicioLaborados.setError("Ingrese Fecha de Inicio Laboral ej: (2020-06-12)")
            } else if (txtDiasFinLaborados.text.toString().trim().isEmpty()) {
                txtDiasFinLaborados.setError("Ingrese Fecha de Fin Laboral ej: (2020-12-17)")
            } else if (txtDiasInasistencia.text.toString().trim().isEmpty()) {
                txtDiasInasistencia.setError("Ingrese Número de Días Inasistencia")
            } else {
                // Obtener los valores de entrada del usuario
                val nombreEmpleado = txtNombreEmpleado.text.toString()
                val salarioMensual = txtSalarioMensual.text.toString().toDouble()
                val diasInicioLaborados = txtDiasInicioLaborados.text.toString()
                val diasFinLaborados = txtDiasFinLaborados.text.toString()
                val diasInasistencia = txtDiasInasistencia.text.toString()

                // Crear una instancia de PrestacionesModel
                val prestacionesModel = PrestacionesModel()
                prestacionesModel.setNombreEmpleado(nombreEmpleado)
                prestacionesModel.setSalarioMensual(salarioMensual)
                prestacionesModel.setDiasInicioLaborados(diasInicioLaborados)
                prestacionesModel.setDiasFinLaborados(diasFinLaborados)
                prestacionesModel.setDiasInasistencia(diasInasistencia)

                // Calcular las prestaciones
                val prestaciones = prestacionesModel.calcularPrestaciones()

                // Asignar el resultado al EditText
                txResultado.setText(prestaciones)
            }
        }
    }
}
