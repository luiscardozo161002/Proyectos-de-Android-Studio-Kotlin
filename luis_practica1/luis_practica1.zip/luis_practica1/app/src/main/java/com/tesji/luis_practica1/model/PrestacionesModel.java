package com.tesji.luis_practica1.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class PrestacionesModel {
    private String nombreEmpleado = "";
    private double salarioMensual = 0.0;
    private String diasInicioLaborados = "";
    private String diasFinLaborados = "";
    private String diasInasistencia = "";

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public void setSalarioMensual(double salarioMensual) {
        this.salarioMensual = salarioMensual;
    }

    public void setDiasInicioLaborados(String diasInicioLaborados) {
        this.diasInicioLaborados = diasInicioLaborados;
    }

    public void setDiasFinLaborados(String diasFinLaborados) {
        this.diasFinLaborados = diasFinLaborados;
    }

    public void setDiasInasistencia(String diasInasistencia) {
        this.diasInasistencia = diasInasistencia;
    }

    public String calcularPrestaciones() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date fechaInicio = dateFormat.parse(diasInicioLaborados);
            Date fechaFin = dateFormat.parse(diasFinLaborados);
            long diferenciaMillis = fechaFin.getTime() - fechaInicio.getTime();
            long diasTrabajados = TimeUnit.DAYS.convert(diferenciaMillis, TimeUnit.MILLISECONDS);

            if (diasTrabajados < 0) {
                return "La fecha de fin debe ser posterior a la fecha de inicio.";
            }

            int diasFaltados = Integer.parseInt(diasInasistencia);
            long diasTrabajadosDescontandoFaltas = diasTrabajados - diasFaltados;
            int mesesTrabajados = (int) (diasTrabajadosDescontandoFaltas / 30.44);

            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(fechaInicio);
            int anioInicio = calInicio.get(Calendar.YEAR);

            Calendar calFin = Calendar.getInstance();
            calFin.setTime(fechaFin);
            int anioFin = calFin.get(Calendar.YEAR);

            boolean esBisiesto = esBisiesto(anioInicio) || esBisiesto(anioFin);

            double aguinaldo = (salarioMensual * mesesTrabajados / 12) * (diasTrabajadosDescontandoFaltas / (30.44 * 30));
            double gratificacion = salarioMensual * 0.073 * mesesTrabajados * (diasTrabajadosDescontandoFaltas / (30.44 * 30));
            double primaVacacional = salarioMensual * 0.058 * mesesTrabajados * (diasTrabajadosDescontandoFaltas / (30.44 * 30));

            double totalPrestaciones = aguinaldo + gratificacion + primaVacacional;
            double salarioTotal = salarioMensual * mesesTrabajados;

            StringBuilder resultado = new StringBuilder();
            resultado.append("Nombre del empleado: ").append(nombreEmpleado).append("\n");
            resultado.append("Sueldo Mensual: ").append(salarioMensual).append("\n");
            resultado.append("El empleado trabajó ").append(diasTrabajadosDescontandoFaltas).append(" días (").append(mesesTrabajados).append(" meses).\n");
            resultado.append("Aguinaldo: ").append(aguinaldo).append("\n");
            resultado.append("Gratificación: ").append(gratificacion).append("\n");
            resultado.append("Prima Vacacional: ").append(primaVacacional).append("\n");
            resultado.append("Total de prestaciones: ").append(totalPrestaciones).append("\n");
            resultado.append("Salario total: ").append(salarioTotal).append("\n");
            resultado.append("¿Año Bisiesto? ").append(esBisiesto ? "Sí" : "No");

            return resultado.toString();
        } catch (ParseException e) {
            return "Error en el cálculo de prestaciones.";
        }
    }

    private boolean esBisiesto(int anio) {
        return (anio % 4 == 0 && (anio % 100 != 0 || anio % 400 == 0));
    }
}
