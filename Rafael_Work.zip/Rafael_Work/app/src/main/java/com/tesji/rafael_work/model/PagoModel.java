package com.tesji.rafael_work.model;

public class PagoModel {
}