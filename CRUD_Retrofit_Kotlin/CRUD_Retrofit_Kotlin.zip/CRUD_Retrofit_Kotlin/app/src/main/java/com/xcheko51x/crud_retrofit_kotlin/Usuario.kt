package com.xcheko51x.crud_retrofit_kotlin

data class Usuario(
    var idUsuario: Int,
    var nombre: String,
    var email: String
)
